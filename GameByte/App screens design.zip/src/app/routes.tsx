import { useState, type ReactNode } from "react";
import { createBrowserRouter, Link, NavLink, useLocation, useNavigate } from "react-router";
import {
  Award,
  BarChart3,
  Bell,
  BookOpen,
  BrainCircuit,
  Check,
  ChevronRight,
  CircleHelp,
  Code2,
  Compass,
  Flame,
  Globe2,
  GraduationCap,
  Home,
  LayoutGrid,
  LockKeyhole,
  Medal,
  Network,
  Play,
  Rocket,
  Search,
  Sparkles,
  Target,
  Trophy,
  UserRound,
  UsersRound,
  Wifi,
  X,
  Zap,
} from "lucide-react";
import mascot from "@/imports/WhatsApp_Image_2026-08-21_at_12.07.41.jpeg";
import appIcon from "@/imports/WhatsApp_Image_2026-08-21_at_12.09.51__1_.jpeg";

const primaryNav = [
  { to: "/", label: "Início", icon: Home, end: true },
  { to: "/trilhas", label: "Trilhas", icon: LayoutGrid },
  { to: "/ranking", label: "Ranking", icon: Trophy },
];

function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-2.5">
      <div className={`overflow-hidden rounded-[15px] ${compact ? "size-9" : "size-10"} bg-[#6b4ee8] shadow-[0_8px_18px_rgba(94,67,221,.28)]`}>
        <img src={appIcon} alt="Bora" className="size-full object-cover" />
      </div>
      {!compact && <span className="font-display text-[24px] font-bold tracking-[-.06em] text-white"><span className="font-normal">Byte</span></span>}
    </div>
  );
}

function XP({ value = "1.240 XP" }: { value?: string }) {
  return <div className="inline-flex items-center gap-1.5 rounded-full border border-[#8d75f3]/30 bg-[#5d42ca]/30 px-3 py-1.5 font-mono text-[10px] font-medium uppercase tracking-[.08em] text-[#e9e4ff]"><Zap size={13} className="fill-[#f8c662] text-[#f8c662]" />{value}</div>;
}

function Avatar({ className = "" }: { className?: string }) {
  return <div className={`flex items-center justify-center rounded-full bg-gradient-to-br from-[#fdc8a9] to-[#d98874] font-display font-bold text-[#5a2e44] ${className}`}>M</div>;
}

function AppShell({ children }: { children: ReactNode }) {
  const location = useLocation();
  const [notice, setNotice] = useState(false);
  return (
    <div className="min-h-screen bg-[#160d2e] font-body text-[#f8f6ff] selection:bg-[#9a7cff] selection:text-white">
      <div className="pointer-events-none fixed left-[14%] top-[-180px] size-[460px] rounded-full bg-[#4d2daa] opacity-30 blur-[105px]" />
      <div className="pointer-events-none fixed bottom-[-240px] right-[-120px] size-[520px] rounded-full bg-[#7034b4] opacity-20 blur-[120px]" />
      <div className="relative mx-auto flex min-h-screen max-w-[1440px]">
        <aside className="hidden w-[238px] shrink-0 flex-col border-r border-white/[.07] bg-[#120a29]/65 px-5 py-7 lg:flex">
          <Logo />
          <nav className="mt-12 space-y-2">
            {primaryNav.map(({ to, label, icon: Icon, end }) => <NavLink key={to} to={to} end={end} className={({ isActive }) => `flex items-center gap-3 rounded-2xl px-3 py-3 text-[13px] font-bold transition ${isActive ? "bg-[#6546dc] text-white shadow-[0_10px_22px_rgba(77,48,190,.3)]" : "text-[#a89dc6] hover:bg-white/[.05] hover:text-white"}`}><Icon size={18} />{label}</NavLink>)}
          </nav>
          <div className="mt-auto overflow-hidden rounded-[24px] border border-white/[.08] bg-gradient-to-br from-[#312059] to-[#211143] p-4">
            <img src={mascot} alt="Mascote Bora" className="-mb-6 ml-auto h-24 w-24 rounded-[22px] object-cover object-[center_40%] mix-blend-screen opacity-90" />
            <p className="relative z-10 font-display text-[16px] font-bold leading-tight">Bora para o<br />próximo nível?</p>
            <p className="mt-2 text-[11px] leading-4 text-[#b9add7]">Conclua uma missão hoje.</p>
          </div>
        </aside>
        <div className="min-w-0 flex-1 pb-20 lg:pb-0">
          <header className="flex h-[76px] items-center justify-between border-b border-white/[.07] bg-[#160d2e]/75 px-5 backdrop-blur-xl md:px-8">
            <div className="lg:hidden"><Logo /></div>
            <div className="hidden lg:flex items-center gap-3 text-[12px] text-[#a399bf]"><span>Bootcamp ADS</span><ChevronRight size={14} /><span className="text-[#edeaff]">{location.pathname === "/ranking" ? "Ranking" : location.pathname === "/trilhas" ? "Trilhas" : "Início"}</span></div>
            <div className="flex items-center gap-3"><XP /><button onClick={() => setNotice(!notice)} aria-label="Notificações" className="relative flex size-10 items-center justify-center rounded-full border border-white/[.08] bg-white/[.045] text-[#c9c1df] hover:bg-white/[.09]"><Bell size={18} />{notice && <span className="absolute right-2 top-2 size-2 rounded-full bg-[#ffbf66] ring-2 ring-[#20123f]" />}</button><Link to="/perfil" aria-label="Abrir perfil"><Avatar className="size-9 text-[13px]" /></Link></div>
          </header>
          {children}
        </div>
      </div>
      <nav className="fixed inset-x-0 bottom-0 z-30 flex justify-around border-t border-white/[.08] bg-[#180d33]/95 px-4 pb-[max(12px,env(safe-area-inset-bottom))] pt-3 backdrop-blur-xl lg:hidden">
        {primaryNav.map(({ to, label, icon: Icon, end }) => <NavLink key={to} to={to} end={end} className={({ isActive }) => `flex min-w-16 flex-col items-center gap-1 text-[10px] font-bold ${isActive ? "text-[#b9a7ff]" : "text-[#9184aa]"}`}>{({ isActive }) => <><span className={`flex size-9 items-center justify-center rounded-xl ${isActive ? "bg-[#5e40d3] text-white" : ""}`}><Icon size={18} /></span>{label}</>}</NavLink>)}
      </nav>
    </div>
  );
}

function Stat({ icon: Icon, label, value, accent }: { icon: typeof Flame; label: string; value: string; accent: string }) {
  return <div className="rounded-[22px] border border-white/[.07] bg-white/[.045] p-4"><div className={`flex size-9 items-center justify-center rounded-xl ${accent}`}><Icon size={18} /></div><p className="mt-5 text-[11px] font-bold uppercase tracking-[.12em] text-[#a69bbf]">{label}</p><p className="mt-1 font-display text-[23px] font-bold tracking-[-.05em] text-white">{value}</p></div>;
}

function HomePage() {
  const navigate = useNavigate();
  const [done, setDone] = useState(false);
  return <AppShell><main className="mx-auto max-w-[1160px] px-5 py-7 md:px-8 md:py-10"><section className="relative min-h-[150px] overflow-hidden rounded-[29px] border border-[#856ce9]/25 bg-gradient-to-br from-[#5e3ed2] via-[#3d277f] to-[#211140] shadow-[0_18px_50px_rgba(0,0,0,.22)] sm:min-h-[168px] px-[30px] py-[20px]"><div className="pointer-events-none absolute -right-9 -top-16 size-48 rounded-full border-[24px] border-[#9d87f3]/25" /><img src={mascot} alt="Mascote Bora celebrando sua evolução" className="pointer-events-none absolute -bottom-2 -right-2 h-32 w-32 rounded-[30px] object-cover object-[center_34%] mix-blend-screen opacity-90 sm:-bottom-8 sm:right-6 sm:h-48 sm:w-48 sm:rounded-[43px]" /><div className="relative z-10 max-w-[138px] sm:max-w-[540px]"><p className="font-mono text-[10px] uppercase tracking-[.18em] text-[#d5caff]">Quinta · 21 de agosto</p><h1 className="mt-3 font-display text-[clamp(1.55rem,4vw,3rem)] font-bold leading-[.96] tracking-[-.06em] text-white">Bom te ver de volta,<br />Marina <span className="text-[#f6c768]">✦</span></h1></div></section><div className="mt-5 grid grid-cols-3 gap-3"><Stat icon={Flame} label="Sequência" value="12 dias" accent="bg-[#55304c] text-[#ff9b73]" /><Stat icon={Zap} label="XP total" value="1.240" accent="bg-[#55472a] text-[#f6c768]" /><Stat icon={Trophy} label="Sua posição" value="#18" accent="bg-[#443475] text-[#ae9aff]" /></div>
      <section className="mt-10"><div className="flex items-end justify-between"><div><p className="font-display text-[24px] font-bold tracking-[-.045em] text-white">Continue de onde parou</p><p className="mt-1 text-[13px] text-[#9e94b5]">ADS · Módulo 02 de 06</p></div><button onClick={() => navigate("/trilhas")} className="hidden items-center gap-1 text-[12px] font-bold text-[#ab98ff] sm:flex">Ver trilha <ChevronRight size={15} /></button></div><div className="mt-4 grid gap-4 md:grid-cols-[1.18fr_.82fr]"><article className="rounded-[28px] border border-white/[.08] bg-[#211440] p-5 md:p-6"><div className="flex items-start justify-between"><div className="flex size-12 items-center justify-center rounded-[17px] bg-[#46347d] text-[#b6a4ff]"><BarChart3 size={23} /></div><span className="rounded-full bg-[#33245d] px-3 py-1 text-[10px] font-bold uppercase tracking-[.12em] text-[#b9aaff]">+80 XP</span></div><p className="mt-5 text-[11px] font-bold uppercase tracking-[.13em] text-[#9588ad]">Módulo 2 · Métricas</p><h3 className="mt-1 font-display text-[23px] font-bold tracking-[-.045em] text-white">O que faz um anúncio performar?</h3><p className="mt-2 max-w-[480px] text-[13px] leading-5 text-[#aaa0c0]">Teste seus conhecimentos em CTR, CPC e ROAS com um desafio rápido.</p><div className="mt-5 flex items-center gap-4"><button onClick={() => setDone(!done)} className={`flex items-center gap-2 rounded-2xl px-4 py-3 text-[13px] font-bold transition ${done ? "bg-[#5fbe91] text-[#112a21]" : "bg-[#7352df] text-white hover:bg-[#8061e8]"}`}>{done ? <><Check size={16} /> Missão concluída</> : <><Play size={16} fill="currentColor" /> Iniciar desafio</>}</button>{!done && <span className="text-[11px] text-[#9186aa]">5 min · 3 questões</span>}</div></article><article className="rounded-[28px] border border-white/[.08] bg-gradient-to-b from-[#28204c] to-[#20163e] p-5"><div className="flex items-center gap-3"><div className="flex size-10 items-center justify-center rounded-2xl bg-[#f2bb5e] text-[#472c11]"><Award size={20} /></div><div><p className="font-display text-[17px] font-bold tracking-[-.035em]">Quase lá!</p><p className="text-[11px] text-[#a79abb]">Próxima conquista</p></div></div><div className="mt-7 flex items-end justify-between"><p className="max-w-36 font-display text-[22px] font-bold leading-[1.03] tracking-[-.05em]">Exploradora de dados</p><span className="font-mono text-[10px] text-[#f5c463]">3/5</span></div><div className="mt-4 h-2 overflow-hidden rounded-full bg-white/[.09]"><div className="h-full w-3/5 rounded-full bg-[#f3bd5d]" /></div></article></div></section>
      <section className="mt-10"><div className="flex items-end justify-between"><div><p className="font-display text-[24px] font-bold tracking-[-.045em] text-white">Suas trilhas</p><p className="mt-1 text-[13px] text-[#9e94b5]">Escolha uma habilidade para evoluir.</p></div><Link to="/trilhas" className="hidden text-[12px] font-bold text-[#ab98ff] sm:block">Explorar todas</Link></div><TrackRail /></section></main></AppShell>;
}

const tracks = [
  { id: "ads", name: "Análise e Desenvolvimento de Sistemas", short: "ADS", lessons: "8 de 24 aulas", progress: 34, icon: Code2, gradient: "from-[#744ce2] to-[#3e2a83]", soft: "bg-[#442e8a]", xp: "80 XP" },
  { id: "logic", name: "Lógica de programação", short: "Lógica", lessons: "3 de 18 aulas", progress: 18, icon: BrainCircuit, gradient: "from-[#287a8e] to-[#1d405e]", soft: "bg-[#1a596d]", xp: "60 XP" },
  { id: "network", name: "Fundamentos de redes", short: "Redes", lessons: "0 de 16 aulas", progress: 0, icon: Wifi, gradient: "from-[#aa4d89] to-[#5c235d]", soft: "bg-[#742b68]", xp: "70 XP" },
];

function TrackRail() { return <div className="mt-4 grid gap-3 md:grid-cols-3">{tracks.map((track) => { const Icon = track.icon; return <Link key={track.id} to={`/trilhas#${track.id}`} className={`group overflow-hidden rounded-[25px] bg-gradient-to-br ${track.gradient} p-5 transition duration-200 hover:-translate-y-1 hover:shadow-[0_20px_30px_rgba(0,0,0,.2)]`}><div className="flex items-start justify-between"><span className="flex size-11 items-center justify-center rounded-2xl bg-white/[.14]"><Icon size={22} /></span><span className="rounded-full bg-black/[.16] px-2.5 py-1 font-mono text-[9px] font-medium">{track.xp}</span></div><p className="mt-8 font-display text-[20px] font-bold leading-[1.05] tracking-[-.045em]">{track.short}</p><p className="mt-1 text-[11px] text-white/70">{track.lessons}</p><div className="mt-4 h-1.5 overflow-hidden rounded-full bg-black/[.18]"><div className="h-full rounded-full bg-white" style={{ width: `${track.progress}%` }} /></div></Link>})}</div>; }

function TracksPage() { const [filter, setFilter] = useState("Todas"); const filters = ["Todas", "Em andamento", "Não iniciadas"]; return <AppShell><main className="mx-auto max-w-[1160px] px-5 py-8 md:px-8 md:py-10"><div className="flex flex-col justify-between gap-5 md:flex-row md:items-end"><div className="relative pr-20 sm:pr-0"><img src={mascot} alt="Mascote Bora guiando as trilhas" className="absolute right-0 top-0 size-16 rounded-[21px] object-cover object-[center_36%] mix-blend-screen opacity-90 sm:hidden" /><p className="font-mono text-[10px] uppercase tracking-[.18em] text-[#a996ff]">Seu mapa de aprendizagem</p><h1 className="mt-3 font-display text-[clamp(2.3rem,4vw,3.5rem)] font-bold leading-[.98] tracking-[-.065em]">Trilhas para<br />desbloquear seu potencial.</h1></div><div className="flex gap-2 overflow-auto pb-1">{filters.map((item) => <button key={item} onClick={() => setFilter(item)} className={`whitespace-nowrap rounded-full px-4 py-2 text-[11px] font-bold ${filter === item ? "bg-[#6b4be0] text-white" : "border border-white/[.08] bg-white/[.04] text-[#aaa0bf]"}`}>{item}</button>)}</div></div><div className="mt-9 grid gap-5 lg:grid-cols-3">{tracks.filter((track) => filter === "Todas" || (filter === "Em andamento" ? track.progress > 0 : track.progress === 0)).map((track, index) => <TrackDetail key={track.id} track={track} unlocked={index !== 2} />)}</div></main></AppShell>; }

function TrackDetail({ track, unlocked }: { track: (typeof tracks)[number]; unlocked: boolean }) { const [started, setStarted] = useState(track.progress > 0); const Icon = track.icon; const activities = track.id === "ads" ? ["Como funciona a web", "Métricas que importam", "Desafio: leia o dashboard"] : track.id === "logic" ? ["Variáveis e valores", "Condições na prática", "Desafio: encontre o bug"] : ["A internet por dentro", "Dispositivos da rede", "Desafio: conecte os nós"]; return <article id={track.id} className="overflow-hidden rounded-[29px] border border-white/[.08] bg-[#211440]"><div className={`relative h-28 overflow-hidden bg-gradient-to-br ${track.gradient} p-5`}><div className="absolute -right-8 -bottom-9 size-32 rounded-full border-[20px] border-white/[.12]" /><span className="relative flex size-12 items-center justify-center rounded-[17px] bg-white/[.15]"><Icon size={24} /></span></div><div className="p-5"><div className="flex items-start justify-between gap-3"><div><p className="font-display text-[21px] font-bold leading-[1.07] tracking-[-.045em]">{track.name}</p><p className="mt-2 text-[11px] text-[#aa9fbe]">{track.lessons}</p></div><XP value={track.xp} /></div><div className="mt-5 h-1.5 overflow-hidden rounded-full bg-white/[.08]"><div className="h-full rounded-full bg-[#a58bff]" style={{ width: `${track.progress}%` }} /></div><div className="mt-5 space-y-2.5">{activities.map((activity, i) => <div key={activity} className="flex items-center gap-3 text-[12px] text-[#d3cce2]"><span className={`flex size-6 shrink-0 items-center justify-center rounded-full text-[10px] ${i === 0 && track.progress ? "bg-[#7454df] text-white" : "bg-white/[.06] text-[#9387a7]"}`}>{i === 0 && track.progress ? <Check size={13} /> : i + 1}</span>{activity}</div>)}</div><button disabled={!unlocked} onClick={() => setStarted(!started)} className={`mt-6 flex w-full items-center justify-center gap-2 rounded-2xl py-3 text-[12px] font-bold ${unlocked ? "bg-[#6a49dd] text-white hover:bg-[#795ae7]" : "cursor-not-allowed bg-white/[.06] text-[#82769c]"}`}>{unlocked ? <>{started ? "Continuar trilha" : "Começar trilha"}<ChevronRight size={15} /></> : <><LockKeyhole size={15} /> desbloqueie no nível 4</>}</button></div></article>; }

const leaderboard = [
  { name: "João Victor", xp: "2.480", streak: 28, initials: "JV", tone: "from-[#fde1b7] to-[#c6805c]" },
  { name: "Letícia Ramos", xp: "2.330", streak: 21, initials: "LR", tone: "from-[#c8defa] to-[#658cc5]" },
  { name: "Carlos Eduardo", xp: "2.110", streak: 19, initials: "CE", tone: "from-[#e7c1cc] to-[#aa677b]" },
  { name: "Ana Clara", xp: "1.970", streak: 17, initials: "AC", tone: "from-[#d6ccff] to-[#806ac3]" },
  { name: "Rafael Nunes", xp: "1.860", streak: 15, initials: "RN", tone: "from-[#cde7db] to-[#4e997a]" },
];

function RankingPage() { const [period, setPeriod] = useState("Esta semana"); return <AppShell><main className="mx-auto max-w-[1020px] px-5 py-8 md:px-8 md:py-10"><div className="flex flex-col items-start justify-between gap-5 sm:flex-row sm:items-end"><div className="relative pr-20 sm:pr-0"><img src={mascot} alt="Mascote Bora acompanhando o ranking" className="absolute right-0 top-0 size-16 rounded-[21px] object-cover object-[center_36%] mix-blend-screen opacity-90 sm:hidden" /><p className="font-mono text-[10px] uppercase tracking-[.18em] text-[#a996ff]">Classificação ADS</p><h1 className="mt-3 font-display text-[clamp(2.35rem,4vw,3.7rem)] font-bold leading-[.98] tracking-[-.065em]">Ranking da galera.</h1><p className="mt-3 max-w-md text-[13px] leading-6 text-[#a69bbd]">Cada missão concluída soma XP. Acompanhe seu lugar entre os alunos de ADS.</p></div><button onClick={() => setPeriod(period === "Esta semana" ? "Este mês" : "Esta semana")} className="rounded-full border border-white/[.09] bg-white/[.045] px-4 py-2 text-[11px] font-bold text-[#d7d1e5]">{period} <ChevronRight className="ml-1 inline" size={14} /></button></div><section className="mt-8 grid gap-4 md:grid-cols-3">{leaderboard.slice(0, 3).map((user, index) => { const medals = ["🥇", "🥈", "🥉"]; return <article key={user.name} className={`relative overflow-hidden rounded-[28px] border p-5 ${index === 0 ? "border-[#d8b265]/40 bg-gradient-to-b from-[#433159] to-[#271a43] md:-translate-y-4" : "border-white/[.08] bg-[#211440]"}`}><span className="absolute right-5 top-4 text-[24px]">{medals[index]}</span><div className={`flex size-14 items-center justify-center rounded-full bg-gradient-to-br ${user.tone} font-display text-[16px] font-bold text-[#372247]`}>{user.initials}</div><p className="mt-5 font-display text-[19px] font-bold tracking-[-.04em]">{user.name}</p><p className="mt-1 font-mono text-[10px] uppercase tracking-[.1em] text-[#f1c668]">{user.xp} XP</p><div className="mt-5 flex items-center gap-1.5 text-[11px] text-[#af9fc3]"><Flame size={14} className="fill-[#ff965e] text-[#ff965e]" /> {user.streak} dias de sequência</div></article>})}</section><section className="mt-5 overflow-hidden rounded-[28px] border border-white/[.08] bg-[#211440]"><div className="flex items-center justify-between border-b border-white/[.07] px-5 py-4"><p className="font-display text-[19px] font-bold tracking-[-.04em]">Tabela completa</p><UsersRound size={18} className="text-[#a795da]" /></div>{leaderboard.map((user, index) => <div key={user.name} className={`flex items-center gap-4 px-5 py-4 ${index < leaderboard.length - 1 ? "border-b border-white/[.06]" : ""}`}><span className="w-5 font-mono text-[11px] text-[#9a8fb1]">0{index + 1}</span><div className={`flex size-10 items-center justify-center rounded-full bg-gradient-to-br ${user.tone} text-[11px] font-bold text-[#382448]`}>{user.initials}</div><div className="min-w-0 flex-1"><p className="text-[13px] font-bold text-[#f4f0ff]">{user.name}</p><p className="mt-0.5 text-[10px] text-[#968aa9]"><Flame className="mr-1 inline fill-[#ff965e] text-[#ff965e]" size={11} />{user.streak} dias</p></div><p className="font-mono text-[11px] font-medium text-[#f1c668]">{user.xp} XP</p></div>)}<div className="flex items-center gap-4 border-t border-[#8064e6]/20 bg-[#2c2050] px-5 py-4"><span className="w-5 font-mono text-[11px] text-[#c7b8ff]">18</span><Avatar className="size-10 text-[12px]" /><div className="flex-1"><p className="text-[13px] font-bold">Você · Marina</p><p className="mt-0.5 text-[10px] text-[#a699bd]">Faltam 620 XP para o top 10</p></div><p className="font-mono text-[11px] font-medium text-[#f1c668]">1.240 XP</p></div></section></main></AppShell>; }

function LoginPage() { const navigate = useNavigate(); const [loading, setLoading] = useState(false); const login = () => { setLoading(true); window.setTimeout(() => navigate("/"), 650); }; return <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#160d2e] px-5 font-body text-white"><div className="absolute -left-28 top-[-100px] size-[390px] rounded-full bg-[#6944df] opacity-35 blur-[100px]" /><div className="absolute -bottom-40 -right-16 size-[430px] rounded-full bg-[#963c94] opacity-20 blur-[110px]" /><main className="relative grid w-full max-w-[980px] overflow-hidden rounded-[34px] border border-white/[.1] bg-[#20113f]/80 shadow-[0_25px_80px_rgba(0,0,0,.35)] backdrop-blur-xl md:grid-cols-[.95fr_1.05fr]"><section className="relative hidden min-h-[630px] overflow-hidden bg-gradient-to-br from-[#754fdf] via-[#5535b7] to-[#2c165d] p-10 md:block"><div className="absolute -right-20 top-[-70px] size-64 rounded-full border-[30px] border-white/[.12]" /><div className="absolute bottom-[-120px] left-[-70px] size-72 rounded-full border-[34px] border-[#c4b2ff]/20" /><Logo /><div className="relative z-10 mt-16"><p className="font-mono text-[10px] uppercase tracking-[.18em] text-[#dfd6ff]">Seu game de aprendizado</p><h1 className="mt-5 font-display text-[46px] font-bold leading-[.95] tracking-[-.07em]">Aprender pode ser o seu melhor jogo.</h1><p className="mt-6 max-w-72 text-[14px] leading-6 text-[#ded7ff]">Domine habilidades, conclua missões e suba no ranking com a sua turma.</p></div><img src={mascot} alt="Mascote Bora" className="absolute -bottom-9 right-1 h-64 w-64 rounded-[54px] object-cover object-[center_35%] mix-blend-screen opacity-90" /></section><section className="flex min-h-[590px] flex-col justify-center p-7 sm:p-10"><div className="md:hidden"><Logo /></div><div className="mt-10 md:mt-0"><p className="font-mono text-[10px] uppercase tracking-[.18em] text-[#a997ff]">Boas-vindas</p><h2 className="mt-3 font-display text-[34px] font-bold leading-[1] tracking-[-.06em]">Entre e continue sua jornada.</h2><p className="mt-4 text-[13px] leading-6 text-[#aaa0c1]">Use a sua conta institucional para acessar suas trilhas e seu progresso.</p><button onClick={login} disabled={loading} className="mt-8 flex w-full items-center justify-center gap-3 rounded-2xl bg-white py-3.5 text-[13px] font-bold text-[#281a4a] transition hover:bg-[#f2efff] disabled:opacity-70"><span className="grid size-5 place-items-center rounded-full bg-[#4285f4] text-[12px] font-extrabold text-white">G</span>{loading ? "Conectando..." : "Continuar com Google"}</button><div className="my-7 flex items-center gap-3 text-[10px] uppercase tracking-[.12em] text-[#776b91]"><span className="h-px flex-1 bg-white/[.08]" />acesso seguro<span className="h-px flex-1 bg-white/[.08]" /></div><div className="flex items-start gap-3 rounded-2xl border border-[#8066de]/25 bg-[#302051] p-4"><LockKeyhole size={17} className="mt-0.5 shrink-0 text-[#b5a2ff]" /><p className="text-[11px] leading-5 text-[#bbb0ce]">Ao entrar, você concorda com os termos de uso e a política de privacidade do Bora.</p></div></div><p className="mt-9 text-center text-[11px] text-[#837799]">Ainda não tem acesso? <button className="font-bold text-[#b7a5ff]">Fale com sua instituição</button></p></section></main></div>; }

function ProfilePage() { return <AppShell><main className="mx-auto max-w-[860px] px-5 py-10 md:px-8"><div className="relative overflow-hidden rounded-[30px] border border-white/[.08] bg-[#211440] p-5 sm:p-7"><img src={mascot} alt="Mascote Bora no perfil" className="pointer-events-none absolute -right-5 -top-6 size-28 rounded-[34px] object-cover object-[center_36%] mix-blend-screen opacity-60 sm:size-36" /><div className="relative z-10 flex flex-col gap-5 sm:flex-row sm:items-center"><Avatar className="size-20 text-[23px]" /><div className="flex-1"><p className="font-display text-[30px] font-bold tracking-[-.05em]">Marina Silva</p><p className="mt-1 text-[13px] text-[#a69aba]">Bootcamp ADS · Turma 2026.2</p></div><XP /></div><div className="mt-8 grid grid-cols-3 gap-3"><Stat icon={Target} label="Missões" value="18" accent="bg-[#443475] text-[#ae9aff]" /><Stat icon={Trophy} label="Badges" value="04" accent="bg-[#55472a] text-[#f6c768]" /><Stat icon={Flame} label="Streak" value="12" accent="bg-[#55304c] text-[#ff9b73]" /></div></div></main></AppShell>; }

function NotFound() { return <AppShell><main className="grid min-h-[60vh] place-items-center px-6 text-center"><div><p className="font-display text-5xl font-bold">404</p><p className="mt-3 text-[#aaa0c1]">Essa tela não faz parte da sua trilha.</p><Link to="/" className="mt-5 inline-flex rounded-xl bg-[#6b4be0] px-4 py-3 text-sm font-bold">Voltar ao início</Link></div></main></AppShell>; }

export const router = createBrowserRouter([
  { path: "/login", Component: LoginPage },
  { path: "/", Component: HomePage },
  { path: "/trilhas", Component: TracksPage },
  { path: "/ranking", Component: RankingPage },
  { path: "/perfil", Component: ProfilePage },
  { path: "*", Component: NotFound },
]);
